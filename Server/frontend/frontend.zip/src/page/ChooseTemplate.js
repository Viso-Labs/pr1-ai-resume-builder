import "./ChooseTemplate.css";
import React from "react";
import Heder_nav6 from "../components/Heder_nav6";
import { NavLink } from "react-router-dom";

export default function ChooseTemplate() {
  return (
    <div className="bodyc">
       <Heder_nav6 />
       
      <div class="v78_239">
        <span class="v78_240 msset1">TERMS AND CONDITIONS</span>
        <span class="v78_240 msset2">| PRIVACY POLICY</span>
        <span class="v78_240 msset3">| ACCESSIBILITY</span>
        <span class="v78_240 msset4">| CONTACT US</span>
        
        <span class="v78_241">You can always change your template later.</span>
        <span class="v78_242">Template 1</span>
        <span class="v78_243">Template 4</span>
        <span class="v78_244">Template 7</span>
        <span class="v78_245">Template 10</span>
        <span class="v78_246">Template 13</span>
        <span class="v78_247">Template 16</span>
        <span class="v78_248">Template 19</span>
        <span class="v78_249">Template 22</span>
        <span class="v78_250">Template 25</span>
        <NavLink to="/Creation"><span class="v78_251">Template 2</span></NavLink>
        <span class="v78_252">Template 5</span>
        <span class="v78_253">Template 8</span>
        <span class="v78_254">Template 11</span>
        <span class="v78_255">Template 14</span>
        <span class="v78_256">Template 17</span>
        <span class="v78_257">Template 20</span>
        <span class="v78_258">Template 23</span>
        <span class="v78_259">Template 26</span>
        <span class="v78_260">Template 3</span>
        <span class="v78_261">Template 6</span>
        <span class="v78_262">Template 9</span>
        <span class="v78_263">Template 12</span>
        <span class="v78_264">Template 15</span>
        <span class="v78_265">Template 18</span>
        <span class="v78_266">Template 21</span>
        <span class="v78_267">Template 24</span>
        <span class="v78_268">Template 27</span>
        <span class="v78_269">
          Choose from our <span className="bltx_bold">best templates</span> for <span className="bltx_bold">3-5 Years of experience</span>
        </span>
        <div class="v78_270">
          <div class="v78_271 kt"></div>
          <div class="name"></div>
          <div class="v78_273 "></div>
        </div>
        <span class="v78_274">COLOR</span>
        <div class="v78_275 kt"></div>
        <div class="v78_276 kt"></div>
        <div class="v78_277 kt"></div>
        <div class="v78_278 kt"></div>
        <div class="v78_279 kt"></div>
        <div class="v78_280 kt"></div>
        <div class="v78_281 kt"></div>
        <div class="v78_282 kt"></div>
        <div class="v78_283 kt"></div>
        <div class="v78_284 kt"></div>
        <div class="v78_285 kt"></div>
        <div class="v78_286 kt"></div>
        <div class="v78_287 kt"></div>
        <div class="v78_288 kt"></div>
        <div class="v78_289 kt"></div>
        <div class="v78_290 kt"></div>
        <div class="v78_291 kt"></div>
        <div class="v78_292 kt"></div>
        <div class="v78_293 kt"></div>
        <div class="v200_343 kt"></div>
        <div class="v78_294 kt"></div>
        <div class="v78_295 kt"></div>
        <div class="v78_296 kt"></div>
        <div class="v78_297 kt"></div>
        <div class="v78_298 kt"></div>
        <div class="v78_299 kt"></div>
        <div class="v78_300 kt"></div>
        <div class="v78_301 kt"></div>
        <div class="v78_302 kt"></div>
        <div class="v78_303 kt"></div>
        <div class="v78_304 kt"></div>
        <div class="v78_305 kt"></div>
        <div class="v78_306 kt"></div>
        <div class="v78_307 kt"></div>
        <div class="v78_308 kt"></div>
        <div class="v78_309 kt"></div>
        <div class="name"></div>
        <div class="name"></div>

      <div className="footer row">
        <div className="justify-end col-12 d-flex">
          <div className="mt-4 btnchooseleter ms-3 me-3"> <h3>CHOOSE LATER</h3></div>
          <div className="mt-4 btnchoosetemplate ms-3 me-5"><h3>CHOOSE TEMPLATE</h3></div>
        </div>
      </div>
      </div>
    </div>
  );
}
