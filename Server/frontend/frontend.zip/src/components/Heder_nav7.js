import "./Heder_nav7.css";
import React from 'react';
import { Link } from "react-router-dom";



export default function Heder_nav7() {
    return (
        <div class="row">
            <div>
                <div class="row">

                    <nav class="navbar navbar-expand-lg">
                        <div class="container-fluid">
                            <a class="navbar-brand ms-4" href="#">
                           <Link to="/"><img class="logo" src="./images/logo2.png" alt="" /></Link> 
                            </a>

                         


                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false"
                                aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    )
}
